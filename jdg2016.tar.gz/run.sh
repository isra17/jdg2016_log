#!/bin/bash
# Ce script est un exemple pour exécuter votre solution
python3 solution.py

# Décomentez les lignes suivantes si vous utilisez Java:
# javac solution.java &> /dev/null
# java solution

# Ajoutez vos propres commandes si vous utilisez un autre langage.
# Assurez-vous d'ajouter "&> /dev/null" aux commandes de compilation.
